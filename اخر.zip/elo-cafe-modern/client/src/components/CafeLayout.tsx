import { Link, useLocation } from "wouter";
import { ArrowLeft, Instagram, Menu as MenuIcon, ShoppingBag, X } from "lucide-react";
import { useEffect, useState } from "react";

export const logoUrl = "/manus-storage/elo-logo-transparent_3797d99e.png";
export const heroUrl = "/manus-storage/elo-hero_f5c4aac2.jpg";

export function CafeLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  useEffect(() => {
    const read = () => setCartCount(JSON.parse(localStorage.getItem("elo-cart") || "[]").reduce((sum: number, item: { quantity: number }) => sum + item.quantity, 0));
    read(); window.addEventListener("elo-cart-updated", read); return () => window.removeEventListener("elo-cart-updated", read);
  }, []);
  const links = [{ href: "/", label: "الرئيسية" }, { href: "/menu", label: "القائمة" }, { href: "/about", label: "قصتنا" }, { href: "/contact", label: "تواصل معنا" }];
  return <div className="min-h-screen bg-[#f7f1e9] text-[#241815]">
    <header className="site-header">
      <div className="container flex items-center justify-between gap-4">
        <Link href="/" className="brand-lockup"><img className="brand-logo-image" src={logoUrl} alt="إيلو كافيه" /></Link>
        <nav className="hidden md:flex items-center gap-8">{links.map(link => <Link key={link.href} href={link.href} className={`nav-link ${location === link.href ? "active" : ""}`}>{link.label}</Link>)}</nav>
        <div className="flex items-center gap-2"><Link href="/checkout" className="cart-button" aria-label="السلة"><ShoppingBag size={19}/>{cartCount > 0 && <b>{cartCount}</b>}</Link><button className="md:hidden icon-button" onClick={() => setOpen(!open)} aria-label="القائمة">{open ? <X/> : <MenuIcon/>}</button></div>
      </div>
      {open && <div className="mobile-nav md:hidden">{links.map(link => <Link key={link.href} href={link.href} onClick={() => setOpen(false)} className="mobile-nav-link">{link.label}<ArrowLeft size={16}/></Link>)}</div>}
    </header>
    <main>{children}</main>
    <footer className="footer"><div className="container grid gap-10 md:grid-cols-3"><div><div className="brand-lockup"><img className="brand-logo-image" src={logoUrl} alt="إيلو كافيه" /></div><p className="footer-copy">قهوة تعرفها من زمان، نقدّمها لك بشكل جديد.</p></div><div><p className="footer-title">روابط سريعة</p><div className="footer-links">{links.slice(1).map(l => <Link key={l.href} href={l.href}>{l.label}</Link>)}</div></div><div><p className="footer-title">تابع الحكاية</p><a className="instagram-link" href="https://instagram.com/elo.cafe1" target="_blank" rel="noreferrer"><Instagram size={17}/> @elo.cafe1</a></div></div><div className="container footer-bottom"><span>© 2026 ايلو كافيه</span><span>صُنعت بحب للقهوة</span></div></footer>
  </div>;
}

export function ProductImage({ src, alt }: { src?: string; alt: string }) { return <img className="product-image" src={src || "/manus-storage/elo-espresso_81202654.jpg"} alt={alt}/>; }
