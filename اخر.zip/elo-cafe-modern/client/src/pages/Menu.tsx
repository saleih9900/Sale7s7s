import { useMemo, useState } from "react";
import { Check, Plus, Search, SlidersHorizontal } from "lucide-react";
import { CafeLayout, ProductImage } from "@/components/CafeLayout";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const fallback = [
  { id: 1, categoryId: 1, name: "إسبريسو", description: "مركّز، عميق، وبنهاية ناعمة", price: "12.00", imageUrl: "/manus-storage/elo-espresso_81202654.jpg", isAvailable: 1 },
  { id: 2, categoryId: 1, name: "كابتشينو", description: "رغوة مخملية مع نكهة متوازنة", price: "16.00", imageUrl: "/manus-storage/elo-cappuccino_dbdb4cbd.jpg", isAvailable: 1 },
  { id: 3, categoryId: 1, name: "لاتيه إيلو", description: "حليب ناعم ولمسة إسبريسو", price: "18.00", imageUrl: "/manus-storage/elo-latte_67c25fca.jpg", isAvailable: 1 },
  { id: 4, categoryId: 1, name: "كولد برو", description: "استخلاص بارد، نكهة صافية", price: "20.00", imageUrl: "/manus-storage/elo-latte_67c25fca.jpg", isAvailable: 1 },
  { id: 5, categoryId: 2, name: "تشيزكيك إيلو", description: "ناعم بلمسة كراميل خفيفة", price: "22.00", imageUrl: "/manus-storage/elo-dessert_4ff8dec5.jpg", isAvailable: 1 },
  { id: 6, categoryId: 2, name: "كرواسون زبدة", description: "مخبوز طازجًا كل صباح", price: "14.00", imageUrl: "/manus-storage/elo-dessert_4ff8dec5.jpg", isAvailable: 1 },
];

export default function Menu() {
  const { data } = trpc.catalog.products.useQuery({});
  const [category, setCategory] = useState("all"); const [query, setQuery] = useState("");
  const products = (data?.length ? data : fallback) as typeof fallback;
  const filtered = useMemo(() => products.filter(p => (category === "all" || String(p.categoryId) === category) && p.name.includes(query)), [products, category, query]);
  const add = (product: typeof fallback[number]) => { const cart = JSON.parse(localStorage.getItem("elo-cart") || "[]"); const found = cart.find((item: { productId: number }) => item.productId === product.id); if (found) found.quantity += 1; else cart.push({ productId: product.id, productName: product.name, quantity: 1, unitPrice: product.price, imageUrl: product.imageUrl }); localStorage.setItem("elo-cart", JSON.stringify(cart)); window.dispatchEvent(new Event("elo-cart-updated")); toast.success(`تمت إضافة ${product.name} إلى السلة`); };
  return <CafeLayout><section className="page-hero"><div className="container"><div className="section-kicker light">قائمة إيلو</div><h1>كل ما تحبه،<br/><em>في مكان واحد.</em></h1><p>اختر مزاجك اليوم، واترك الباقي علينا.</p></div></section><section className="container menu-page"><div className="menu-toolbar"><div className="filter-tabs"><button className={category === "all" ? "selected" : ""} onClick={() => setCategory("all")}>الكل</button><button className={category === "1" ? "selected" : ""} onClick={() => setCategory("1")}>مشروبات</button><button className={category === "2" ? "selected" : ""} onClick={() => setCategory("2")}>حلويات</button></div><label className="search-field"><Search size={17}/><input placeholder="ابحث عن منتج" value={query} onChange={e => setQuery(e.target.value)}/></label><SlidersHorizontal className="mobile-filter" size={18}/></div><div className="menu-grid">{filtered.map(product => <article className="menu-card" key={product.id}><div className="menu-card-image"><ProductImage src={product.imageUrl} alt={product.name}/><span className="availability"><Check size={12}/> متوفر</span></div><div className="menu-card-info"><div><h3>{product.name}</h3><p>{product.description}</p></div><div className="menu-card-footer"><strong>{product.price} <small>ر.س</small></strong><button onClick={() => add(product)} aria-label={`إضافة ${product.name}`}><Plus size={18}/></button></div></div></article>)}</div></section></CafeLayout>;
}
