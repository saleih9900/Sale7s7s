import { ArrowLeft, ChevronDown, Clock3, MapPin, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { CafeLayout, heroUrl, ProductImage } from "@/components/CafeLayout";
import { trpc } from "@/lib/trpc";

const featured = [
  { id: 1, name: "لاتيه إيلو", description: "حليب ناعم مع لمسة إسبريسو متوازنة", price: "18.00", imageUrl: "/manus-storage/elo-latte_67c25fca.jpg" },
  { id: 2, name: "كابتشينو", description: "رغوة مخملية وقهوة محمصة بعناية", price: "16.00", imageUrl: "/manus-storage/elo-cappuccino_dbdb4cbd.jpg" },
  { id: 3, name: "تشيزكيك إيلو", description: "قطعة ناعمة بلمسة كراميل خفيفة", price: "22.00", imageUrl: "/manus-storage/elo-dessert_4ff8dec5.jpg" },
];

export default function Home() {
  const { data } = trpc.catalog.products.useQuery({});
  const products = (data?.length ? data : featured) as typeof featured;
  return <CafeLayout>
    <section className="hero-section"><img src={heroUrl} alt="أجواء ايلو كافيه"/><div className="hero-overlay"/><div className="container hero-content"><motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7 }} className="max-w-xl"><span className="eyebrow"><Sparkles size={14}/> قهوة لها حضور</span><h1>المكلا تعرف القهوة من زمان،<em>بس إيلو قدّمها بشكل جديد.</em></h1><p>من أول رشفة، تبدأ حكاية مختلفة. محاصيل مختارة، تفاصيل محسوبة، ومكان يخلّي الوقت ألطف.</p><div className="hero-actions"><Link href="/menu" className="button button-light">استكشف القائمة <ArrowLeft size={17}/></Link><Link href="/about" className="text-link">اكتشف قصتنا <ArrowLeft size={15}/></Link></div></motion.div></div><div className="hero-scroll"><ChevronDown size={17}/><span>اكتشف إيلو</span></div></section>
    <section className="intro-section container"><div className="section-kicker">01 — روح المكان</div><div className="intro-grid"><h2>نصنع لحظات<br/><span>تستحق أن تُعاش.</span></h2><div><p className="lead">إيلو ليس مجرد كوب قهوة. هو مساحة تجمع الطعم، الدفء، والتفاصيل الصغيرة التي تصنع يومًا أجمل.</p><Link href="/about" className="underlined-link">أعرف أكثر عن إيلو <ArrowLeft size={16}/></Link></div></div></section>
    <section className="featured-section"><div className="container"><div className="section-heading"><div><div className="section-kicker">02 — اختياراتنا</div><h2>الأكثر طلبًا</h2></div><Link href="/menu" className="underlined-link">شاهد القائمة كاملة <ArrowLeft size={16}/></Link></div><div className="product-grid">{products.slice(0, 3).map((product, i) => <motion.article key={product.id} className="product-card" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * .1 }}><ProductImage src={product.imageUrl} alt={product.name}/><div className="product-card-content"><div><h3>{product.name}</h3><p>{product.description}</p></div><span className="price">{product.price} <small>ر.س</small></span></div><Link href="/menu" className="card-link">أضف إلى طلبك <ArrowLeft size={15}/></Link></motion.article>)}</div></div></section>
    <section className="story-strip"><div className="container story-grid"><div><div className="section-kicker light">03 — تفاصيل تفرق</div><h2>نكهة تبدأ من<br/><em>الاختيار الصحيح.</em></h2><p>نحمص بحب، ونقدّم بعناية. لأن القهوة المختصة مو مجرد طريقة، هي مزاج كامل.</p><Link href="/contact" className="button button-outline">زرنا اليوم <ArrowLeft size={17}/></Link></div><div className="story-facts"><div><Clock3/><span>يوميًا</span><b>7ص — 12م</b></div><div><MapPin/><span>العنوان</span><b>المكلا، حضرموت</b></div></div></div></section>
  </CafeLayout>;
}
