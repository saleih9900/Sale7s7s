# إعداد Supabase لمشروع ايلو كافيه

يستخدم المشروع PostgreSQL عبر Drizzle، ويفضّل متغير البيئة `SUPABASE_DATABASE_URL` على `DATABASE_URL` عند توفره. لا تضع رابط الاتصال أو كلمة المرور داخل Git أو ملفات المشروع.

## إعداد السر

من Supabase افتح **Project Settings → Database → Connection string → URI**، وانسخ رابط PostgreSQL بعد استبدال كلمة المرور الفعلية. إذا احتوت كلمة المرور على رموز خاصة، استخدم نسخة URL-encoded منها. أضف الرابط في أسرار المشروع باسم `SUPABASE_DATABASE_URL`.

## التحقق

بعد ضبط السر شغّل:

```bash
pnpm vitest run server/supabase.connection.test.ts
node scripts/verify-supabase.mjs
```

## المخطط والبيانات

المخطط المصدر موجود في `drizzle/schema.ts`، وملف migration في `drizzle/migrations-pg/0000_nice_vanisher.sql`. سكربت `scripts/setup-supabase.mjs` ينشئ الجداول ويضيف فئات ومنتجات البداية بطريقة قابلة لإعادة التشغيل دون تكرار المنتجات.

لا يحتوي المستودع على أسرار أو كلمات مرور. بعد إعداد المتغير، شغّل `pnpm test` و`pnpm check` و`pnpm build` قبل النشر.
