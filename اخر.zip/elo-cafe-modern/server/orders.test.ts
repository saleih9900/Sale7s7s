import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function context(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("orders.create", () => {
  it("rejects an order with no items", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.orders.create({
      customerName: "عميل إيلو",
      customerPhone: "0500000000",
      total: "0.00",
      items: [],
    })).rejects.toThrow();
  });

  it("rejects incomplete customer details", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.orders.create({
      customerName: "أ",
      customerPhone: "05",
      total: "12.00",
      items: [{ productId: 1, productName: "إسبريسو", quantity: 1, unitPrice: "12.00" }],
    })).rejects.toThrow();
  });
});

describe("catalog routes", () => {
  it("exposes public catalog procedures", () => {
    expect(appRouter.catalog.products).toBeDefined();
    expect(appRouter.catalog.categories).toBeDefined();
  });
});

describe("admin authorization", () => {
  it("rejects admin procedures for a regular user", async () => {
    const regularUser = { id: 2, openId: "regular-user", email: "user@example.com", name: "User", loginMethod: "manus", role: "user" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    const caller = appRouter.createCaller({ ...context(), user: regularUser });
    await expect(caller.admin.deleteProduct({ id: 1 })).rejects.toThrow();
    await expect(caller.orders.list()).rejects.toThrow();
  });
});

describe("admin input contracts", () => {
  it("validates the required product fields before database access", async () => {
    const admin = { id: 1, openId: "owner", email: "owner@example.com", name: "Owner", loginMethod: "manus", role: "admin" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    const caller = appRouter.createCaller({ ...context(), user: admin });
    await expect(caller.admin.createProduct({ categoryId: 1, name: "قهوة", description: "وصف", price: "bad", imageUrl: "not-url", isAvailable: 1, featured: 0 })).rejects.toThrow();
    await expect(caller.orders.updateStatus({ id: 1, status: "unknown" as never })).rejects.toThrow();
  });
});
