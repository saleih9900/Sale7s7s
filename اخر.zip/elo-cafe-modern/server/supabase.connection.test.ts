import { describe, expect, it } from "vitest";
import postgres from "postgres";

describe("Supabase PostgreSQL connection", () => {
  it("connects using SUPABASE_DATABASE_URL", async () => {
    const connectionString = process.env.SUPABASE_DATABASE_URL;
    expect(connectionString, "SUPABASE_DATABASE_URL is required").toBeTruthy();
    const sql = postgres(connectionString as string, { prepare: false, max: 1, connect_timeout: 5 });
    try {
      const result = await sql`select 1 as ok`;
      expect(Number(result[0]?.ok)).toBe(1);
    } finally {
      await sql.end({ timeout: 5 });
    }
  }, 15_000);
});
