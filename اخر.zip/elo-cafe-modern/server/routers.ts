import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createOrder, deleteProduct, insertProduct, listCategories, listOrders, listProducts, updateOrderStatus, updateProduct } from "./db";

const productInput = z.object({
  categoryId: z.number().int().positive(),
  name: z.string().min(2),
  description: z.string().min(2),
  price: z.string().regex(/^\d+(\.\d{1,2})?$/),
  imageUrl: z.string().url(),
  isAvailable: z.number().int().min(0).max(1).default(1),
  featured: z.number().int().min(0).max(1).default(0),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  catalog: router({
    categories: publicProcedure.query(() => listCategories()),
    products: publicProcedure.input(z.object({ categoryId: z.number().int().positive().optional() }).optional()).query(({ input }) => listProducts(input?.categoryId)),
  }),
  orders: router({
    create: publicProcedure.input(z.object({
      customerName: z.string().min(2), customerPhone: z.string().min(7), notes: z.string().optional(), total: z.string(),
      items: z.array(z.object({ productId: z.number().int(), productName: z.string(), quantity: z.number().int().positive(), unitPrice: z.string() })).min(1),
    })).mutation(({ input }) => createOrder(input)),
    list: adminProcedure.query(() => listOrders()),
    updateStatus: adminProcedure.input(z.object({ id: z.number().int(), status: z.enum(["new", "preparing", "ready", "completed", "cancelled"]) })).mutation(({ input }) => updateOrderStatus(input.id, input.status)),
  }),
  admin: router({
    createProduct: adminProcedure.input(productInput).mutation(({ input }) => insertProduct(input)),
    updateProduct: adminProcedure.input(productInput.extend({ id: z.number().int() })).mutation(({ input }) => { const { id, ...data } = input; return updateProduct(id, data); }),
    deleteProduct: adminProcedure.input(z.object({ id: z.number().int() })).mutation(({ input }) => deleteProduct(input.id)),
  }),
});

export type AppRouter = typeof appRouter;
