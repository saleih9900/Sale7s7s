import { and, desc, eq, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { categories, InsertUser, orderItems, orders, products, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  const connectionString = process.env.SUPABASE_DATABASE_URL || process.env.DATABASE_URL;
  if (!_db && connectionString) {
    try {
      const client = postgres(connectionString, { prepare: false, max: 5 });
      _db = drizzle(client);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId, lastSignedIn: user.lastSignedIn ?? new Date() };
  const updateSet: Record<string, unknown> = { lastSignedIn: values.lastSignedIn };
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  await db.insert(users).values(values).onConflictDoUpdate({ target: users.openId, set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb(); if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listCategories() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(categories).orderBy(categories.id);
}

export async function listProducts(categoryId?: number) {
  const db = await getDb(); if (!db) return [];
  const where = categoryId ? eq(products.categoryId, categoryId) : undefined;
  return db.select().from(products).where(where).orderBy(desc(products.featured), desc(products.createdAt));
}

export async function getProductsByIds(ids: number[]) {
  const db = await getDb(); if (!db || ids.length === 0) return [];
  return db.select().from(products).where(inArray(products.id, ids));
}

export async function listOrders() {
  const db = await getDb(); if (!db) return [];
  return db.select().from(orders).orderBy(desc(orders.createdAt));
}

export async function createOrder(input: { customerName: string; customerPhone: string; notes?: string; total: string; items: Array<{ productId: number; productName: string; quantity: number; unitPrice: string }> }) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const orderNumber = `ELO-${Date.now().toString().slice(-6)}`;
  const result = await db.insert(orders).values({ orderNumber, customerName: input.customerName, customerPhone: input.customerPhone, notes: input.notes || null, total: input.total }).returning({ id: orders.id });
  const orderId = result[0]?.id;
  if (!orderId) throw new Error("Order could not be created");
  await db.insert(orderItems).values(input.items.map((item) => ({ orderId, ...item })));
  return { orderNumber, orderId };
}

export async function insertProduct(input: typeof products.$inferInsert) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.insert(products).values(input).returning({ id: products.id });
}

export async function updateProduct(id: number, input: Partial<typeof products.$inferInsert>) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.update(products).set({ ...input, updatedAt: new Date() }).where(eq(products.id, id)).returning({ id: products.id });
}

export async function deleteProduct(id: number) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.delete(products).where(eq(products.id, id)).returning({ id: products.id });
}

export async function updateOrderStatus(id: number, status: typeof orders.$inferInsert.status) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.update(orders).set({ status }).where(eq(orders.id, id)).returning({ id: orders.id });
}
